<?php
session_start(); // Inicia a sessão

// Verificar se o código de verificação foi feito antes
if (!isset($_SESSION['codigo'])) {
    echo "<script>alert('Código de verificação não realizado! Redirecionando para a página de verificação.'); window.location.href = 'verificar_codigo.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nova_senha = $_POST['nova_senha']; // Nova senha fornecida pelo usuário

    // Verificar se a nova senha foi fornecida corretamente
    if (empty($nova_senha)) {
        echo "<script>alert('Por favor, insira uma nova senha.');</script>";
    } else {
        // Aqui você deve salvar a nova senha no banco de dados (simulado pela sessão neste caso)
        $_SESSION['user_password'] = password_hash($nova_senha, PASSWORD_DEFAULT); // Salva a nova senha criptografada

        echo "<script>
            alert('Senha redefinida com sucesso!');
            window.location.href = 'index.php'; // Redireciona para a página de login
        </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(45deg, cyan, yellow);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .tela-recuperar {
            background-color: rgba(0, 0, 0, 0.9);
            padding: 40px;
            border-radius: 15px;
            color: white;
            width: 100%;
            max-width: 350px;
            text-align: center;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: none;
            outline: none;
            font-size: 16px;
            border-radius: 8px;
        }
        button {
            background-color: dodgerblue;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: deepskyblue;
        }
    </style>
</head>
<body>
    <div class="tela-recuperar">
        <h2>Digite a nova senha</h2>
        <form action="nova_senha.php" method="POST">
            <input type="password" name="nova_senha" placeholder="Nova senha" required>
            <button type="submit">Redefinir Senha</button>
        </form>
    </div>
</body>
</html>
