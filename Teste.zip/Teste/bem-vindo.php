<?php
session_start();

$nome_usuario = $_SESSION['user_name'];  // Usa o mesmo nome armazenado na sessão
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem-vindo</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
            background-image: linear-gradient(45deg, cyan, yellow);
        }
        .welcome-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .welcome-card h1 {
            color: #333;
        }
        .welcome-card p {
            color: #666;
        }
        .btn {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="welcome-card">
        <h1>Bem-vindo ao Nosso Site, <?php echo htmlspecialchars($nome_usuario); ?>!</h1>
        <p>Ficamos felizes em ter você aqui. Explore e aproveite o conteúdo!</p>
        <a href="tela.php" class="btn">Começar</a>
    </div>
</body>
</html>