<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artigos sobre Saúde Mental</title>
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(45deg, #6a11cb, #2575fc);
            color: white;
            margin: 0;
            padding: 0;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        h1 {
            font-size: 3rem;
            margin-top: 20px;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
        }
        .artigos-container {
            margin-top: 30px;
            padding: 20px;
            width: 90%;
            max-width: 700px;
        }
        .artigo {
            background: rgba(0, 0, 0, 0.3);
            margin: 15px 0;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
        .artigo h2 {
            margin-bottom: 10px;
            font-size: 1.8rem;
        }
        .artigo p {
            font-size: 1.2rem;
        }
        footer {
            margin-top: 30px;
            font-size: 1rem;
            color: #ddd;
        }
        footer a {
            color: #00bcd4;
            text-decoration: none;
            font-weight: bold;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <h1>Artigos sobre Saúde Mental</h1>
    <div class="artigos-container">
        <div class="artigo">
            <h2>A Música como Terapia</h2>
            <p>A música tem o poder de curar e aliviar a ansiedade. Descubra como ela pode melhorar sua saúde mental.</p>
        </div>
        <div class="artigo">
            <h2>Benefícios da Música para o Estresse</h2>
            <p>Saiba como músicas suaves podem ajudar a reduzir o estresse e promover relaxamento.</p>
        </div>
        <div class="artigo">
            <h2>Como Criar uma Playlist para Relaxamento</h2>
            <p>Dicas para montar a playlist perfeita para aliviar a mente e o corpo.</p>
        </div>
    </div>

    <footer>
        <a href="tela.php">Voltar à Página Inicial</a>
    </footer>

</body>
</html>
