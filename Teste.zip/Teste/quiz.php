<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz: Descubra Seu Instrumento Musical</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(45deg, #6a11cb, #2575fc);
            color: black;
            margin: 150px;
            padding: 130px;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            max-width: 600px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }
        h2 {
            text-align: center;
        }
        .question {
            margin-bottom: 15px;
            text-align: left;
            display: none; /* Esconde todas as perguntas inicialmente */
        }
        .active {
            display: block; /* Apenas a pergunta atual será exibida */
        }
        .result {
            margin-top: 20px;
            font-weight: bold;
            font-size: 1.2rem;
            color: #333;
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
        }
        button {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            margin: 10px 5px;
        }
        button:hover {
            background-color: #0056b3;
        }
        label {
            display: block;
            margin: 5px 0;
            cursor: pointer;
        }
        footer {
            margin-top: 30px;
            font-size: 1rem;
            color: #ddd;
        }
        footer a {
            color: #00bcd4;
            text-decoration: none;
            font-weight: bold;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Descubra Seu Instrumento Musical</h2>
        <form id="quizForm">
            <div class="question active">
                <p>1. Como você prefere passar seu tempo livre?</p>
                <label><input type="radio" name="q1" value="A"> A) Eventos sociais e conhecer novas pessoas</label>
                <label><input type="radio" name="q1" value="B"> B) Lendo ou assistindo filmes</label>
                <label><input type="radio" name="q1" value="C"> C) Aprendendo algo novo</label>
                <label><input type="radio" name="q1" value="D"> D) Fazendo esportes</label>
                <label><input type="radio" name="q1" value="E"> E) Meditando ou refletindo</label>
            </div>
            
            <div class="question">
                <p>2. Como você descreveria sua personalidade?</p>
                <label><input type="radio" name="q2" value="A"> A) Energético(a)</label>
                <label><input type="radio" name="q2" value="B"> B) Calmo(a)</label>
                <label><input type="radio" name="q2" value="C"> C) Analítico(a)</label>
                <label><input type="radio" name="q2" value="D"> D) Divertido(a)</label>
                <label><input type="radio" name="q2" value="E"> E) Criativo(a)</label>
            </div>

            <div class="question">
                <p>3. Em um grupo de amigos, qual papel você costuma desempenhar?</p>
                <label><input type="radio" name="q3" value="A"> A) O líder, sempre puxando conversas e atividades.</label>
                <label><input type="radio" name="q3" value="B"> B) O(a) ouvinte, que sempre oferece bons conselhos.</label>
                <label><input type="radio" name="q3" value="C"> C) O organizador, planejando encontros e horários.</label>
                <label><input type="radio" name="q3" value="D"> D) O engraçado, que gosta de fazer todos rirem.</label>
                <label><input type="radio" name="q3" value="E"> E) O pensador, que compartilha novas ideias e reflexões.</label>
            </div>

            <div class="question">
                <p>4. O que te motiva a começar algo novo?</p>
                <label><input type="radio" name="q4" value="A"> A) O desejo de explorar e experimentar.</label>
                <label><input type="radio" name="q4" value="B"> B) A vontade de entender como as coisas funcionam.</label>
                <label><input type="radio" name="q4" value="C"> C) Um objetivo claro e desafiador.</label>
                <label><input type="radio" name="q4" value="D"> D) A oportunidade de me divertir e relaxar.</label>
                <label><input type="radio" name="q4" value="E"> E) A chance de expressar meus sentimentos e pensamentos.</label>
            </div>

            <button type="button" onclick="prevQuestion()">Anterior</button>
            <button type="button" onclick="nextQuestion()">Próximo</button>
            <button type="button" onclick="calcularResultado()" style="display:none;">Descobrir</button>
        </form>
        <div class="result" id="resultado"></div>
    </div>

    <footer>
        <a href="tela.php">Voltar à Página Inicial</a>
    </footer>

    <script>
        let currentQuestion = 0;
        let questions = document.querySelectorAll('.question');
        let nextBtn = document.querySelectorAll('button')[1];
        let prevBtn = document.querySelectorAll('button')[0];
        let discoverBtn = document.querySelectorAll('button')[2];

        function showQuestion(index) {
            questions.forEach((q, i) => {
                q.classList.toggle('active', i === index);
            });

            prevBtn.style.display = index === 0 ? "none" : "inline-block";
            nextBtn.style.display = index === questions.length - 1 ? "none" : "inline-block";
            discoverBtn.style.display = index === questions.length - 1 ? "inline-block" : "none";
        }

        function nextQuestion() {
            if (currentQuestion < questions.length - 1) {
                currentQuestion++;
                showQuestion(currentQuestion);
            }
        }

        function prevQuestion() {
            if (currentQuestion > 0) {
                currentQuestion--;
                showQuestion(currentQuestion);
            }
        }

        function calcularResultado() {
            let respostas = {};
            let radios = document.querySelectorAll('input[type=radio]:checked');

            if (radios.length < questions.length) {
                document.getElementById("resultado").innerText = "Responda todas as perguntas!";
                return;
            }

            radios.forEach(radio => respostas[radio.name] = radio.value);
            
            let contagem = { A: 0, B: 0, C: 0, D: 0, E: 0 };
            Object.values(respostas).forEach(v => contagem[v]++);

            let maior = Object.keys(contagem).reduce((a, b) => contagem[a] > contagem[b] ? a : b);
            let resultadoTexto = ["Bateria, Trompete", "Violão, Flauta", "Teclado, Guitarra", "Percussão, Ukulele", "Piano, Violino"][["A","B","C","D","E"].indexOf(maior)];

            document.getElementById("resultado").innerText = `Seu instrumento é: ${resultadoTexto}`;
            document.getElementById("resultado").style.opacity = "1";
        }

        showQuestion(currentQuestion);
    </script>
</body>
</html>
