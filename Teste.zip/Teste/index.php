<?php
// login_process.php (A lógica de autenticação será processada aqui)

session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomeDigitado = $_POST['name'];
    $senhaDigitada = $_POST['senha'];

    // Verifica se o nome de usuário existe na sessão
    if (isset($_SESSION['user_name']) && $_SESSION['user_name'] === $nomeDigitado) {
        // Verifica a senha
        if (password_verify($senhaDigitada, $_SESSION['user_password'])) {
            echo "<script>
                alert('Login bem-sucedido!');
                window.location.href = 'bem-vindo.php'; // Redireciona para a área logada
            </script>";                
        } else {
            echo "<script>alert('Senha incorreta!');</script>";
        }
    } else {
        echo "<script>alert('Usuário não encontrado!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(45deg, cyan, yellow);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .tela-login {
            background-color: rgba(0, 0, 0, 0.9);
            padding: 40px;
            border-radius: 15px;
            color: white;
            width: 100%;
            max-width: 350px;
            text-align: center;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: none;
            outline: none;
            font-size: 16px;
            border-radius: 8px;
        }
        button {
            background-color: dodgerblue;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: deepskyblue;
        }
        .links {
            margin-top: 15px;
            font-size: 14px;
        }
        .links a {
            color: cyan;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="tela-login">
        <h1>Login</h1>
        <form action="index.php" method="POST">
            <input type="text" name="name" value="<?php echo isset($_SESSION['user_name']) ? $_SESSION['user_name'] : ''; ?>" placeholder="Digite seu nome" required>
            <input type="password" name="senha" placeholder="Digite sua senha" required>
            <button type="submit">Entrar</button>
        </form>
        <?php if (isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
        <div class="links">
            <a href="cadastro.php">Cadastre-se</a><br>        
	<a href="recuperar_senha.php">Esqueceu sua senha?</a>
</body>
</html>
