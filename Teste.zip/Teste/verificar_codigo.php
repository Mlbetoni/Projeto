<?php
session_start(); // Inicia a sessão

// Simulando o envio do código (geralmente seria gerado e enviado via e-mail)
if (!isset($_SESSION['codigo'])) {
    $_SESSION['codigo'] = '979895'; // Gerar ou definir o código de verificação
}

// Verificar se o código foi enviado via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Captura o código inserido pelo usuário
    $codigo_inserido = $_POST['codigo']; 

    // Verifica se o código de verificação armazenado na sessão é igual ao código inserido
    if ($codigo_inserido == $_SESSION['codigo']) {
        // Código correto, redireciona para a página de redefinir senha
        echo "<script>
            alert('Código de verificação correto! Agora você pode redefinir sua senha.');
            window.location.href = 'nova_senha.php'; // Redireciona para a página de redefinir senha
        </script>";
        exit();
    } else {
        // Caso o código esteja incorreto
        echo "<script>alert('Código incorreto! Tente novamente.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Código</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(45deg, cyan, yellow);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .tela-codigo {
            background-color: rgba(0, 0, 0, 0.9);
            padding: 40px;
            border-radius: 15px;
            color: white;
            width: 100%;
            max-width: 350px;
            text-align: center;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: none;
            outline: none;
            font-size: 16px;
            border-radius: 8px;
        }
        button {
            background-color: dodgerblue;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: deepskyblue;
        }
    </style>
</head>
<body>
    <div class="tela-codigo">
        <h2>Verifique seu código</h2>
        <form action="verificar_codigo.php" method="POST">
            <input type="text" name="codigo" placeholder="Código de 6 dígitos" required>
            <button type="submit">Verificar</button>
        </form>
    </div>
</body>
</html>
