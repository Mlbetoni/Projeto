<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Simulação: verificar se o e-mail foi cadastrado
    if (isset($_SESSION['user_email']) && $_SESSION['user_email'] === $email) {
        // Gerar código de verificação (simulação de envio de e-mail)
        $_SESSION['reset_code'] = rand(100000, 999999);
        echo "<script>
            alert('Código de verificação enviado para o seu e-mail!');
            window.location.href = 'verificar_codigo.php';
        </script>";
        exit();
    } else {
        echo "<script>alert('E-mail não encontrado!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(45deg, cyan, yellow); /* Cor de fundo com gradiente */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .tela-recuperar {
            background-color: rgba(0, 0, 0, 0.9);
            padding: 40px;
            border-radius: 15px;
            color: white;
            width: 100%;
            max-width: 350px;
            text-align: center;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: none;
            outline: none;
            font-size: 16px;
            border-radius: 8px;
        }
        button {
            background-color: dodgerblue;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: deepskyblue;
        }
    </style>
</head>
<body>
    <div class="tela-recuperar">
        <h2>Esqueceu sua senha?</h2>
        <form action="esqueceu_senha.php" method="POST">
            <input type="email" name="email" placeholder="Digite seu e-mail" required>
            <button type="submit">Enviar Código</button>
        </form>
    </div>
</body>
</html>
