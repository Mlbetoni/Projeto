<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tocando sua Mente</title>
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(45deg, #6a11cb, #2575fc);
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            text-align: center;
        }
        h1 {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
        }
        p {
            font-size: 1.3rem;
            margin-bottom: 25px;
            max-width: 600px;
            line-height: 1.6;
        }
        .btn {
            background: linear-gradient(90deg, #00bcd4, #0288d1);
            color: white;
            font-size: 1.2rem;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            margin: 10px;
            transition: all 0.3s ease-in-out;
            display: inline-block;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .btn:hover {
            background: linear-gradient(90deg, #0288d1, #00bcd4);
            transform: scale(1.08);
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.3);
        }
        .logo {
            width: 150px;
            margin-bottom: 20px;
            filter: drop-shadow(2px 4px 6px rgba(0, 0, 0, 0.3));
        }
        .content {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            max-width: 700px;
        }
        footer {
            margin-top: 50px;
            font-size: 0.9rem;
            color: #ddd;
        }
    </style>
</head>
<body>
    <img src="imagens/logo.png" alt="Logo Tocando sua Mente" class="logo">
    <h1>Bem-vindo ao Tocando sua Mente</h1>
    <p>Descubra o instrumento que inspira sua alma.</p>
    <div class="content">
        <a href="playlist.php" class="btn">🎵 Ouça a Playlist</a>
        <a href="artigos.php" class="btn">🧠 Saúde Mental</a>
        <a href="quiz.php" class="btn">🎸 Quiz Musical</a>
        <a href="sobre.php" class="btn">ℹ️ Sobre Nós</a>
    </div>
    <footer>&copy; 2025 Tocando sua Mente - Todos os direitos reservados</footer>
    <footer>
        <a href="index.php">Voltar à Página Inicial</a>
    </footer>	
    <!-- Verificação do Chatling -->
    <script>
        window.onload = function() {
            console.log("Carregando Chatling...");
            if (window.chtlConfig && window.chtlConfig.chatbotId) {
                console.log("Chatbot ID encontrado: " + window.chtlConfig.chatbotId);
            } else {
                console.error("Erro ao carregar o Chatling.");
            }
        }
    </script>

    <!-- Chatling Chatbot -->
    <script> window.chtlConfig = { chatbotId: "5933921539" } </script>
    <script async data-id="5933921539" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>
</body>
</html>
