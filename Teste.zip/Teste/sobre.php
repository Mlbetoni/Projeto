<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(45deg, #6a11cb, #2575fc);
            color: white;
            margin: 0;
            padding: 0;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .sobre-container {
            max-width: 600px;
            background: rgba(0, 0, 0, 0.3);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        h1 {
            font-size: 2.5rem;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
        }
        p {
            font-size: 1.2rem;
            line-height: 1.6;
        }
        footer {
            margin-top: 20px;
            font-size: 1rem;
            color: #ddd;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .social-links {
            margin-top: 10px;
            display: flex;
            gap: 15px;
        }
        .social-links a {
            color: #00bcd4;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
        }
        .social-links a img {
            width: 24px;
            height: 24px;
            margin-right: 8px;
	    border-radius: 50%;
        }
        .social-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="sobre-container">
        <h1>Sobre Nós</h1>
        <p> Aqui, acreditamos no poder da música para transformar vidas. Nosso objetivo é proporcionar conteúdo de qualidade sobre relaxamento, bem-estar e autoconhecimento por meio da música.</p>
        <p>Explore nossa playlist relaxante, descubra artigos sobre saúde mental e faça o quiz para descobrir qual instrumento combina com você!</p>
    </div>

    <footer>
        <a href="tela.php">Voltar à Página Inicial</a>
        <div class="social-links">
            <a href="https://www.instagram.com/mlbetoni" target="_blank">
                <img src="imagens/instagram-icon.png" alt="Instagram"> MLbetoni
            </a>
        </div>
    </footer>

</body>
</html>
