<?php
// cadastro_process.php (Aqui você processaria o cadastro no banco de dados)

session_start(); // Inicia a sessão

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Captura os dados do formulário
    $nome = $_POST['name'];
    $email = $_POST['email']; // Captura o e-mail
    $codigo = $_POST['codigo']; // Captura o Codigo
    $senha = $_POST['senha']; // Para um sistema real, é essencial criptografar a senha!

    // Salva os dados na sessão (simulação de banco de dados)
    $_SESSION['user_name'] = $nome;
    $_SESSION['user_email'] = $email; // Armazena o e-mail na sessão    
    $_SESSION['user_password'] = password_hash($senha, PASSWORD_DEFAULT);
if  ($codigo == "979895"){
    $_SESSION['codigo'] = $codigo;
    header("Location: nova_senha.php");  // Redireciona para a página de Nova-Senha
        }
    // Exibe mensagem e redireciona para login
    echo "<script>
        alert('Cadastro realizado com sucesso!');
        window.location.href = 'index.php'; // Redireciona para a página de login
    </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(45deg, cyan, yellow);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: rgba(0, 0, 0, 0.9);
            padding: 30px;
            border-radius: 15px;
            color: white;
            width: 90%;
            max-width: 400px;
            text-align: center;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: none;
            outline: none;
            font-size: 16px;
            border-radius: 8px;
        }
        .radio-group {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin: 10px 0;
        }
        .radio-group label {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        button {
            background-color: dodgerblue;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 15px;
        }
        button:hover {
            background-color: deepskyblue;
        }
        .links {
            margin-top: 15px;
            font-size: 14px;
        }
        .links a {
            color: cyan;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Cadastro</h2>
        <form action="cadastro.php" method="POST">
            <input type="text" name="name" placeholder="Digite seu nome" required>
            <input type="email" name="email" placeholder="Digite seu e-mail" required>
            <input type="tel" name="telefone" placeholder="(XX) XXXXX-XXXX" required>
            
            <label>Sexo</label>
            <div class="radio-group">
                <label><input type="radio" name="sexo" value="masculino" required> Masculino</label>
                <label><input type="radio" name="sexo" value="feminino"> Feminino</label>
                <label><input type="radio" name="sexo" value="outro"> Outro</label>
            </div>

            <input type="date" name="data_nascimento" required>
            <input type="text" name="cidade" placeholder="Digite sua cidade" required>
            
                <select name="estado" required>
                <option value="">Selecione um estado</option>
                <option value="BA">Bahia</option>
                <option value="CE">Ceará</option>
                <option value="GO">Goiás</option>
                <option value="MG">Minas Gerais</option>
                <option value="PE">Pernambuco</option>
                <option value="PR">Paraná</option>
                <option value="RJ">Rio de Janeiro</option>
                <option value="RS">Rio Grande do Sul</option>
                <option value="SC">Santa Catarina</option>
                <option value="SP">São Paulo</option>
                <option value="Outro">Outro</option>
            </select>

            <input type="text" name="endereco" placeholder="Digite seu endereço" required>
            <input type="password" name="senha" placeholder="Digite sua senha" required>
            
            <button type="submit">Cadastrar</button>
        </form>
        <div class="links">
            <a href="index.php">Já tem uma conta? Faça login</a>
        </div>
    </div>
</body>
</html>
